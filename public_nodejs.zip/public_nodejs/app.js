  const express = require("express");
const path = require("path");
const app = express();
const fs = require('fs');
require("dotenv").config();
const haid = process.env.Api_Haidar_Bedr;
const hai = process.env.felo_belo;

// Use static middleware to serve public files
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Error handling middleware
app.use((err, req, res, next) => {
  res.status(err.status || 500).send({
    error: {
      status: err.status || 500,
      message: err.message || 'Internal Server Error'
    }
  });
});
app.use("/static", express.static(path.resolve(__dirname, "public", "static")));
app.get("/static/js/apps.js", (req, res) => {
    res.setHeader("Content-Type", "text/javascript");
    res.sendFile(path.resolve(__dirname, "public", "static", "js", "apps.js"));
});

app.get("/autocode", (req, res) => {

    res.send("<script>localStorage.setItem('uni','wtni-bshre1');window.location.href = '/';</script>");

});
  app.get("/damascus", (req, res) => {

    res.send("<script>localStorage.setItem('uni','dama');window.location.href = '/#/Biology';</script>");

});

  app.get("/tishreen", (req, res) => {
 res.send("<script>localStorage.setItem('uni','tsh');window.location.href = '/#/Biology';</script>");

});
   app.get("/nour", (req, res) => {
 res.send("<script>localStorage.setItem('uni','wnti-bhsre1');window.location.href = '/#/Biology';</script>");

});
     app.get("/mayshalloul", (req, res) => {
 res.send("<script>localStorage.setItem('uni','wnti-bhsre1');window.location.href = '/#/Biology';</script>");

});
app.get(/^\/static\/uni\/wtni-bshre[\d]*\/?(.*)$/, (req, res) => {

  const filePath = path.join(__dirname, 'public', 'static', 'uni', 'wtni-bshre', req.params[0]);


  // Check if the file exists

  fs.access(filePath, fs.constants.F_OK, (err) => {

    if (err) {

      // If the file does not exist, redirect the user to the root path

      res.redirect('/');

    } else {

      // If the file exists, send the file

      res.sendFile(filePath);

    }

  });

});
app.get(/^\/static\/uni\/wnti-bhsre[\d]*\/?(.*)$/, (req, res) => {

  const filePath = path.join(__dirname, 'public', 'static', 'uni', 'wnti-bhsre', req.params[0]);


  // Check if the file exists

  fs.access(filePath, fs.constants.F_OK, (err) => {

    if (err) {

      // If the file does not exist, redirect the user to the root path

      res.redirect('/');

    } else {

      // If the file exists, send the file

      res.sendFile(filePath);

    }

  });

});
  


app.get("/*", (req, res) => {
    res.sendFile(path.resolve(__dirname, "public", "index.html"));
});

// Handle POST request
app.post('/asd', (req, res) => {
  try {
    const filename = path.join(__dirname, haid, hai, 'users.json');
    const users = JSON.parse(fs.readFileSync(filename));
    const newName = req.body.name;
    const inputCode = req.body.code;
    const codesData = fs.readFileSync(path.join(__dirname, haid, hai, 'codes.json'));
    const codes = JSON.parse(codesData);
    if (codes[inputCode]) {
      if (codes[inputCode]['validate'] === 0) {
        res.send("<script>alert('This code has already been used'); window.location.href = '/'</script>");
      }
      else if (codes[inputCode]['validate'] >= 1 && codes[inputCode]['type'] === 'free') {
        const shortenedName = newName.substring(0, 13);
        users.push({ name: shortenedName });
        fs.writeFileSync(filename, JSON.stringify(users));
        codes[inputCode]['validate'] -= 1; // Subtract 1 from the 'validate' value
        fs.writeFileSync(path.join(__dirname, haid, hai, 'codes.json'), JSON.stringify(codes));
        res.send("<script>localStorage.setItem('uni','wnti-bshre');alert('تم تفعيل كود النسخة المجانية!');window.location.href = '/';</script>");
      }  
      else if (codes[inputCode]['validate'] >= 1 && codes[inputCode]['type'] === 'promo') {
        const shortenedName = newName.substring(0, 13);
        users.push({ name: shortenedName });
        fs.writeFileSync(filename, JSON.stringify(users));
        codes[inputCode]['validate'] -= 1; // Subtract 1 from the 'validate' value
        fs.writeFileSync(path.join(__dirname, haid, hai, 'codes.json'), JSON.stringify(codes));
        res.send("<script>localStorage.setItem('uni','wnti-bhsre1');alert('تم تفعيل كود أفضل مصدر للدورات');window.location.href = '/';</script>");
      }
      else if (codes[inputCode]['validate'] === 1 && codes[inputCode]['type'] === 'paid') {
        const shortenedName = newName.substring(0, 13);
        users.push({ name: shortenedName });
        fs.writeFileSync(filename, JSON.stringify(users));
        codes[inputCode]['validate'] = 0;
        fs.writeFileSync(path.join(__dirname, haid, hai, 'codes.json'), JSON.stringify(codes));
        res.send("<script>localStorage.setItem('uni','wnti-bhsre1');alert('تم تفعيل كود أفضل مصدر للدورات!');window.location.href = '/';</script>");
      }
    } else {
      res.send("<script> alert('الكود غير موجود!');window.location.href = '/';</script>");
    }
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});