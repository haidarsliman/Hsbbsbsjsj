const getSuccessResponse = (message,uni) => {
    return `<script>alert('${message}');localStorage.setItem('uni', '${uni}');window.location.href = '/'; </script>`;
  };
  
  module.exports = { getSuccessResponse };