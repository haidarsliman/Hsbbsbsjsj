const path = require('path');

const fs = require('fs');
const { getSuccessResponse } = require('../utils/response.js');
require("dotenv").config();

const apiHaidarBedr = process.env.Api_Haidar_Bedr;
const feloBelo = process.env.felo_belo;

const validateCode = (codes, inputCode) => {
  if (!codes[inputCode]) {
    throw new Error('Code not found');
  }
  return codes[inputCode];
};

const handleCodeSubmission = async (req, res) => {
  try {
    const filename = path.join(__dirname, '..', apiHaidarBedr, feloBelo, 'users.json');
    const usersData = await fs.promises.readFile(filename, 'utf8');
    const users = JSON.parse(usersData);
    const newName = req.body.name;
    const inputCode = req.body.code;
    const codesData = await fs.promises.readFile(path.join(__dirname, '..', apiHaidarBedr, feloBelo, 'codes.json'), 'utf8');
    const codes = JSON.parse(codesData);
    const code = validateCode(codes, inputCode);

    if (code.validate === 0) {
      res.send(getSuccessResponse('عذرا الكود تم استخدامه مسبقاً', code.uni));
    } else if (code.validate >= 1 && code.type === 'free') {
      const shortenedName = newName.substring(0, 13);
      users.push({ name: shortenedName });
      await fs.promises.writeFile(filename, JSON.stringify(users));
      code.validate -= 1;
      await fs.promises.writeFile(path.join(__dirname, '..', apiHaidarBedr, feloBelo, 'codes.json'), JSON.stringify(codes));
      res.send(getSuccessResponse('تم تفعيل كود أفضل مصدر للدورات بنجاح!', code.uni));
    } else if (codes[inputCode]['validate'] >= 1 && codes[inputCode]['type'] === 'promo') {
        const shortenedName = newName.substring(0, 13);
        users.push({ name: shortenedName });
        fs.writeFileSync(filename, JSON.stringify(users));
        codes[inputCode]['validate'] -= 1; // Subtract 1 from the 'validate' value
        fs.writeFileSync(path.join(__dirname, haid, hai, 'codes.json'), JSON.stringify(codes));
        res.send(getSuccessResponse('تم تفعيل كود أفضل مصدر للدورات بنجاح!', code.uni));
      }  
else if (code.validate === 1 && code.type === 'paid') {
      try {
        const shortenedName = newName.substring(0, 13);
        users.push({ name: shortenedName });
        await fs.promises.writeFile(filename, JSON.stringify(users));
        code.validate = 0;
        await fs.promises.writeFile(path.join(__dirname, '..', apiHaidarBedr, feloBelo, 'codes.json'), JSON.stringify(codes));
        res.send(getSuccessResponse('تم تفعيل كود أفضل مصدر للدورات بنجاح!', code.uni));
      } catch (error) {
        
        res.status(500).send('Error occurred while processing request');
      }
    }
  } catch (error) {
   
    res.send(getSuccessResponse('الكود غير موجود', 'none'));
  }
};

module.exports = { handleCodeSubmission };